package com.example.theatremanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TheatremanagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
