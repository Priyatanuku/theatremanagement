package com.example.theatremanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TheatremanagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(TheatremanagementApplication.class, args);
	}

}
